Disposable hosted test gate control. This deliberately fails the existing required check with runtime synthetic input. Do not merge. Retain the rejection evidence, then close and delete this branch.
